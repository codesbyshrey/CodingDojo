public class TestBat {
     public static void main (String[] args) {
          Bat thomas = new Bat();
          // thomas wayne OP

          thomas.attackTown();
          thomas.attackTown();
          thomas.attackTown();

          thomas.eatHumans();
          thomas.eatHumans();

          thomas.fly();
          thomas.fly();

          thomas.displayEnergy();
     }
}
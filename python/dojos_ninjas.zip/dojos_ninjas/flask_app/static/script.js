// Dojos and Ninjas

console.log("Connected to Template");
public class FirstProgram {
     public static void main (String[] args) {
          System.out.println("Welcome to First Java Program");
          String name = "Shreyas Sriram";
          int age = 25;
          String hometown = "Sammamish, WA";

          System.out.println("My name is " + name);
          System.out.println("I am " + age + " years old.");
          System.out.println("My hometown is " + hometown + " \n 98075, USA, Milky Way");
     }
}

// compile attempt 1 gave me three errors, forgot one semicolon and put a semicolon before ()
// compile two worked and program ran great
     // space after \n actually compiles, no need for it